# terraform-mongodb-atlas-configuration

alow the creation of mongodbAtlas projet & set an private link with AWS project. 
it alose create teams(assigne user) with privilege on the project.

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.20 |
| aws | >= 2.28.1 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 2.28.1 |
| mongodbatlas | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| enable\_private\_link | = 1 if you want private link for the project | `number` | `1` | no |
| organization\_id | guid like string (in mongoatlas go in organization --> seting --> Organization ID) | `string` | `"5ed7aab1d3972e2cfa526e25"` | no |
| project\_name | name of the project under the organization | `any` | n/a | yes |
| region\_altas\_style | zone to be use for eks cluster | `string` | `"CA_CENTRAL_1"` | no |
| region\_aws\_style | zone to be use for eks cluster | `string` | `"ca-central-1"` | no |
| security\_group\_ids | list of security group id's | `any` | n/a | yes |
| teams | list of teams for the project & privilege | `any` | n/a | yes |
| vpc\_id | vpc\_id | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| org-id | organization id |
| project-id | project id |
| project-name | project id |
| security-groups-ids | list of security group id |
| subnet-id | subnet id's for private link |
| vpc-id | vpc id for private link |

## test result

```BASH

```
## Versioning

We use [SemVer](http://semver.org/) for versioning. 

## Authors

* pathfinder team
* [@magl003](https://git.bnc.ca/plugins/servlet/user-contributions/magl003)

See also the list of [contributors](https://git.bnc.ca/plugins/servlet/graphs/contributors/APP2325/repos/image-istio-installer?refId=all-branches) who participated in this project.

## License

Proprietary, All rights reserved