# terraform-mongodbatlas

this repo containt BNC IAC for mongoatlas mangement

## they are 2 main core module for:
* create project in an organization: [here for documentation configuration/module](configuration/readme.md)
* create cluster in an project: [here for documentation cluster/module](configuration/readme.md)

they is no module for backup restore since, but you can find exemple [here(test/backup-restore)](test/backup-restore/readme.md)

## test

the goal of the test is to create cluster into a project and to backup & restore into an other.
this test is done at build time in jenkins
> you can simulat jenkins step fvia the makefile

### test step 1: create 2 projets
* source
* target

> located in tests/provision-project

### test step 2: create 2 cluster
* source-for-backup into project source
* restore-from-backup into project target

> located in tests/provision-project

### test step 3: backup & restore

* take a backup from cluster source-for-backup
* restore it into restore-from-backup

## Versioning

We use [SemVer](http://semver.org/) for versioning. 

## Authors

* pathfinder team
* [@magl003](https://git.bnc.ca/plugins/servlet/user-contributions/magl003)

See also the list of [contributors](https://git.bnc.ca/plugins/servlet/graphs/contributors/APP2325/repos/image-istio-installer?refId=all-branches) who participated in this project.

## License

Proprietary, All rights reserved