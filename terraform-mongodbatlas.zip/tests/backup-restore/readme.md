# terraform-mongodb-atlas-backup-restore

alows to create a backup of a mongodb cluster & restore it into an other cluster
> this can be done accross project

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.20 |
| aws | >= 2.28.1 |

## Providers

| Name | Version |
|------|---------|
| mongodbatlas | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| organization\_id | guid like string (in mongoatlas go in organization --> seting --> Organization ID) | `string` | `"5ed7aab1d3972e2cfa526e25"` | no |
| region\_altas\_style | zone to be use for eks cluster | `string` | `"CA_CENTRAL_1"` | no |
| region\_aws\_style | zone to be use for eks cluster | `string` | `"ca-central-1"` | no |
| source\_cluster\_name | (source) Name of the cluster under the project | `any` | n/a | yes |
| source\_project\_name | (source) Name of the project under the organization | `any` | n/a | yes |
| take\_backup\_first | need to take a backup before restore job | `number` | `1` | no |
| target\_cluster\_name | (target) Name of the cluster under the project | `any` | n/a | yes |
| target\_project\_name | (target) Name of the project under the organization | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| backup | id of the source cluster |
| org-id | organization id |
| source-cluster-name | name of the source cluster |
| source-project-id | id of the source project |
| source-project-name | name of the source project |
| target-cluster-name | name of the target cluster |
| target-project-id | id of the target project |
| target-project-name | name of the target project |

## test result

```BASH

```
## Versioning

We use [SemVer](http://semver.org/) for versioning. 

## Authors

* pathfinder team
* [@magl003](https://git.bnc.ca/plugins/servlet/user-contributions/magl003)

See also the list of [contributors](https://git.bnc.ca/plugins/servlet/graphs/contributors/APP2325/repos/image-istio-installer?refId=all-branches) who participated in this project.

## License

Proprietary, All rights reserved