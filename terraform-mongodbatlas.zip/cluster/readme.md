# terraform-mongodb-atlas-cluster

create an mongodb replicaset in AWS,GSP or AZURE via mongoatlas SaaS service

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.20 |
| aws | >= 2.28.1 |

## Providers

| Name | Version |
|------|---------|
| mongodbatlas | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| auto\_scaling\_disk\_gb\_enabled | enable disk autoscaling | `bool` | `true` | no |
| backup\_reference\_hour\_of\_day | UTC Hour of day between 0 and 23, inclusive, representing which hour of the day that Atlas takes snapshots for backup policy items | `number` | `3` | no |
| backup\_reference\_minute\_of\_hour | UTC Minutes after referenceHourOfDay that Atlas takes snapshots for backup policy items. Must be between 0 and 59, inclusive | `number` | `45` | no |
| backup\_restore\_window\_days | Number of days back in time you can restore to with point-in-time accuracy. Must be a positive, non-zero integer | `number` | `4` | no |
| cluster\_name | name of the replicaset | `any` | n/a | yes |
| cluster\_type | (Optional) Specifies the type of the cluster that you want to modify. You cannot convert a sharded cluster deployment to a replica set deployment. possible value(REPLICASET,SHARDED,GEOSHARDED) | `string` | `"REPLICASET"` | no |
| mongo\_db\_major\_version | version of the mongodb | `string` | `"4.2"` | no |
| node\_disk\_size | disk size in GB | `number` | `50` | no |
| node\_provider\_disk\_iops | The maximum input/output operations per second (IOPS) the system can perform | `number` | `150` | no |
| number\_of\_days\_retention\_daily\_backup | number of days the daily backup will be keep | `number` | `2` | no |
| number\_of\_days\_retention\_hourly\_backup | number of days the hourly backup will be keep | `number` | `1` | no |
| number\_of\_months\_retention\_monthly\_backup | number of months the monthly backup will be keep | `number` | `3` | no |
| number\_of\_weeks\_retention\_weekly\_backup | number of weeks the weekly backup will be keep | `number` | `3` | no |
| organization\_id | guid like string (in mongoatlas go in organization --> seting --> Organization ID) | `string` | `"5ed7aab1d3972e2cfa526e25"` | no |
| project\_name | name of the project under the organization | `any` | n/a | yes |
| provider\_backup\_enabled | enable backup | `bool` | `true` | no |
| provider\_encrypt\_ebs\_volume | (Optional- AWS ONLY) If enabled, the Amazon EBS encryption feature encrypts the server’s root volume for both data at rest within the volume and for data moving between the volume and the cluster. Atlas encrypts all cluster storage and snapshot volumes, securing all cluster data on disk: a concept known as encryption at rest, by default | `bool` | `true` | no |
| provider\_instance\_size\_name | Atlas provides different instance sizes, each with a default storage capacity and RAM size.(https://docs.atlas.mongodb.com/cluster-tier/) | `string` | `"M10"` | no |
| provider\_volume\_type | (AWS - Optional) The type of the volume. The possible values are: STANDARD and PROVISIONED. PROVISIONED required if setting IOPS higher than the default instance IOPS | `string` | `"STANDARD"` | no |
| region\_altas\_style | zone to be use for eks cluster | `string` | `"CA_CENTRAL_1"` | no |
| region\_aws\_style | zone to be use for eks cluster | `string` | `"ca-central-1"` | no |
| replication\_factor | number of node in replicaset | `number` | `3` | no |
| target\_cloud\_provider | witch cloud provider your mongodb will be deploy(AWS,GCP,AZURE) | `string` | `"AWS"` | no |

## Outputs

| Name | Description |
|------|-------------|
| cluster-id | cluster id |
| connection-string | connection string via private link |
| instance-size-type | instance size type |
| mongo\_db\_version | version of mongodb servers |
| org-id | organization id |
| project-id | project id |

## test result

```BASH

```
## Versioning

We use [SemVer](http://semver.org/) for versioning. 

## Authors

* pathfinder team
* [@magl003](https://git.bnc.ca/plugins/servlet/user-contributions/magl003)

See also the list of [contributors](https://git.bnc.ca/plugins/servlet/graphs/contributors/APP2325/repos/image-istio-installer?refId=all-branches) who participated in this project.

## License

Proprietary, All rights reserved