# Q- API , Connectivité - service GCP Jenkins (IP dynamique) et MongoDB ATLAS

En lien avec les fonctions de connectivité offerte par ATLAS (IP whitelisting, VPC peering et AWS private link) nous pouvons explorer ces options:

## GCP reserving a static external IP address 
https://cloud.google.com/compute/docs/ip-addresses/reserve-static-external-ip-address

## Construire un VPC entre GCP et AWS (avec Terraform)

https://cloud.google.com/solutions/automated-network-deployment-multicloud


> Ausi voir la doc pour le API pour la gestion d’AWS Private End Point 
https://docs.atlas.mongodb.com/reference/api/private-endpoint/

# Q- MSFT Active directory (on-prem and Azure) for authorisation: 
https://docs.atlas.mongodb.com/reference/api/ldaps-configuration/ 

# Q- Datadog - where to configure within ATLAS

Effectué à l’aide de ce en end-point

https://docs.atlas.mongodb.com/reference/api/third-party-integration-settings-get-one/index.html

Également:  https://docs.atlas.mongodb.com/tutorial/monitoring-integrations/#datadog-integration


# Q- Go library to facilitate ORG, RBAC, and team construct.

Pour l’instant je n’ai rien trouvé. Je continu de chercher.